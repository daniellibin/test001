/*
From:ITC
3
Inappropriate code
3.1
Dead code
3.1.7
constant for statement
*/
#include <stdio.h>
#include <stdlib.h>
extern int sink;
void dead_code_007()
{
	int a = 0;
	int i;
	int ret;
	for (i = 0; i > 1; i++)
	{
		a++; /*Tool should detect this line as error*/ /*ERROR:Dead Code*/
		break;
	}
	ret = a;
	sink = ret;
}

/*
From:ITC
10
Simple type defects
10.1
bool
10.1.2
boolean value assigned to float
*/
#include <stdio.h>
#include <xkeycheck.h>
#include<stdbool.h>                                                                            
bool f(int x, int y) {
	if (x > y) {
		return true;
	}
	else
		return false;
}                                                                                                              
void bool_002() {
	float a;
	a = f(7, 3);/*Tool should detect this line as error*/ /*ERROR:Simple type error*/
} 

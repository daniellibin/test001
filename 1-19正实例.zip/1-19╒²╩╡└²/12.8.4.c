/*
From:ITC
12
Input/Output defects
12.8
Operation relate to file
12.8.4
Read to a file that has only been opened for writing
*/
#include<stdio.h>                                                                                                            
void operation_relate_to_file_004() {
	FILE* fp;
	fp = (FILE*)fopen("x.txt", "w");
	float fa[5];
	fread(fa, 4, 5, fp); /*Tool should detect this line as error*/ /*ERROR:input/output error*/
	fclose(fp);
}
/*
From:ITC
16
Macros defects
16.4
Defining iterators
16.4.1
Macro definition iterator
*/
#define list<int> list_int



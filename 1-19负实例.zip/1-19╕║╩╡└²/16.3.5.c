/*
From:ITC
16
Macros defects
16.3
Controlling macro checking
16.3.5
"Macros should not be used as replacement to ""typdef"" and ""using"""
*/
typedef unsigned int UINT;
typedef int INT;
UINT uabs(INT i);

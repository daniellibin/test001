/*
From:ITC
19
AssertionError
19.2
no assertion
19.2.2
*
*/
#include <cassert>
int no_assertion002() {
    int i;
    int j;
    assert(j!=0);
    int result = i % j;
    return 0;
}

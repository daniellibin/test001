/*
From:ITC
10
Simple type defects
10.1
bool
10.1.8
Returning an integer other than 0 or 1 from a function with boolean return value
*/
#include <stdio.h>
#include <xkeycheck.h>
#include<stdbool.h>                                                                            
bool bool_007() {
	int a ;
	printf(""�������a��ֵ: "");
	scanf(""%d "", &a);
	if (a == 1)
		return true;
	else
		return false;/*Tool should Not detect this line as error*/ /*ERROR:Simple type error*/
}
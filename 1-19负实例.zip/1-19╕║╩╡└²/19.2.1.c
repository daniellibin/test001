/*
From:ITC
19
AssertionError
19.2
no assertion
19.2.1
*
*/
#include "seahorn/seahorn.h"
#include <stdlib.h>
struct my{
  char* x;
  int y;
};
int main(void) {
       return 1;
}

/*
From:ITC
11
STL defects
11.10
"STL boundaries
"
11.10.1

*/

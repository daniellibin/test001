/*
From:ITC
16
Macros defects
16.3
Controlling macro checking
16.3.12
Macro parameter used without parentheses
*/
#define equal(e1,e2) (e1==e2)
